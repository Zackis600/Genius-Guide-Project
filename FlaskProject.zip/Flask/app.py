import os
from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def index():
    template_path = os.path.join(app.root_path, 'templates', 'index.html')
    print(f"Template path: {template_path}")

    page_title = "EduAssist"
    user_name = "John"  # Replace with actual user data
    current_year = 2023  # Replace with the actual current year

    return render_template('index.html', page_title=page_title, user_name=user_name, current_year=current_year)


if __name__ == '__main__':
    app.run(debug=True)






